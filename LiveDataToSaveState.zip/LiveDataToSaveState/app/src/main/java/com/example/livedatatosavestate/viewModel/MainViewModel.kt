package com.example.livedatatosavestate.viewModel

import androidx.lifecycle.ViewModel

class MainViewModel:ViewModel() {
}